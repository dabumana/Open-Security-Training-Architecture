# ifdtool

Contents:

* [Intel IFD Binary Extraction](binary_extraction.md)
* [IFD Layout](layout.md)