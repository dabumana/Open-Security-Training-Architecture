# Eltan vendorcode-specific documentation

This section contains documentation about coreboot on Eltan specific
vendorcode.

## Sections

- [Security](security.md)
