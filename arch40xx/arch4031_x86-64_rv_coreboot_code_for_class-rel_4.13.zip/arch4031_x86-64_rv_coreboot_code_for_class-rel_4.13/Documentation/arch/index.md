# Architecture-specific documentation

This section contains documentation about coreboot on specific CPU
architectures.

## RISC-V

- [RISC-V documentation](riscv/index.md)

## x86
- [x86 documentation](x86/index.md)
