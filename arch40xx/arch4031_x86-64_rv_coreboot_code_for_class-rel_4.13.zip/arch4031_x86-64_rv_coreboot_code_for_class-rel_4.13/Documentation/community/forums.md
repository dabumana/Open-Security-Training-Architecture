# Our forums

The coreboot community has various venues to help each other and discuss the
direction of our project.

## Mailing list

The first address for coreboot related discussion is our mailing list.
You can subscribe on its
[information page](https://mail.coreboot.org/postorius/lists/coreboot.coreboot.org/) and
read its
[archives](https://mail.coreboot.org/hyperkitty/list/coreboot@coreboot.org/).

## IRC

We also have a
[real time chat](https://webchat.freenode.net?channels=%23coreboot)
on the Freenode IRC network's #coreboot channel.
