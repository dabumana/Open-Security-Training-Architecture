# Payload-specific documentation

This section contains documentation about coreboot on specific payloads.

Payloads are run after coreboot has initialized the hardware.
coreboot supports multiple payloads, depending on the architecture of the
selected mainboard.

## FIT

- [uImage.FIT support](fit.md)
