# Obtain Hardware Maintenance Manual of ThinkPads

You are suggested obtain the "Hardware Maintenance Manual" for your corresponding
model as a guidance. Some can be found from [Hardware Specifications of ThinkWiki].

[Hardware Specifications of ThinkWiki]: https://www.thinkwiki.org/wiki/Hardware_Specifications
