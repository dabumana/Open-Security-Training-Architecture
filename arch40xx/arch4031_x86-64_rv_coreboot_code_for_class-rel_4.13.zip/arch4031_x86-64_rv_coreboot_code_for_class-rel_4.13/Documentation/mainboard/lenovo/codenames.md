# Lenovo mainboard codenames

```eval_rst
.. csv-table::
   :header: "Marketing name", "Development codename"
   :file: codenames.csv
```
