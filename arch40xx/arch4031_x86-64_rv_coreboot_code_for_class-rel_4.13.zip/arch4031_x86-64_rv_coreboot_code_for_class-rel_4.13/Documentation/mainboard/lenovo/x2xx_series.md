# Lenovo x2xx series disassembly instructions

Removing the keyboard and palmrest would allow you to access the flash chip.

Read their [Hardware Maintenance Manual](thinkpad_hmm.md) for detailed steps.

## Steps to access the flash IC

* Unplug the main battery
* Remove the keyboard
* Remove the palmrest

