# Intel Northbridge-specific documentation

This section contains documentation about coreboot on specific Intel Northbridges.

## Platforms

- [Haswell](haswell/index.md)
- [Sandy Bridge](sandybridge/index.md)
