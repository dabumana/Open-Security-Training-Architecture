# Intel Haswell documentation

This section describes the Intel Haswell architecture as it relates to
coreboot.

## Proprietary blobs

- [mrc.bin](mrc.bin.md)

## Issues

- [Known issues](known-issues.md)
