# Northbridge-specific documentation

This section contains documentation about coreboot on specific northbridges.

## Vendor

- [Intel](intel/index.md)
