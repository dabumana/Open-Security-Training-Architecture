Upcoming release - coreboot 4.13
================================

The 4.13 release is planned for November 2020.

Update this document with changes that should be in the release notes.

* Please use Markdown.
* See the past few release notes for the general format.
* The chip and board additions and removals will be updated right
  before the release, so those do not need to be added.

Significant changes
-------------------

### Add significant changes here
