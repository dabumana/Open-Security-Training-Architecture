# Qualcomm SOC-specific documentation

This section contains documentation about coreboot on specific Qualcomm SOCs.

## Platforms

- [SC7180 series](sc7180/index.md)
