# SOC-specific documentation

This section contains documentation about coreboot on specific SOCs.

## Vendor

- [AMD](amd/index.md)
- [Cavium](cavium/index.md)
- [Intel](intel/index.md)
- [Qualcomm](qualcomm/index.md)
