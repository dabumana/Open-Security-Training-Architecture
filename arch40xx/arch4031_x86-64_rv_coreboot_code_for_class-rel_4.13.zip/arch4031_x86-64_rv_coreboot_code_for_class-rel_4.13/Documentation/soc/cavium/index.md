# Cavium SOC-specific documentation

This section contains documentation about coreboot on specific Cavium SOCs.

## Platforms

- [CN81xx series](cn81xx/index.md)
- [CN8xxx bootflow](bootflow.md)
