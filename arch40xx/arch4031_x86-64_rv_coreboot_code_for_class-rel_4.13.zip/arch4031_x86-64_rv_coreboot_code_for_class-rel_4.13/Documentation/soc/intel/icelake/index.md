# Intel Ice Lake SOC-specific documentation

This section contains documentation about coreboot on specific Intel "Ice Lake" SOCs.

## Ice Lake coreboot development

- [Ice Lake coreboot development](iceLake_coreboot_development.md)
