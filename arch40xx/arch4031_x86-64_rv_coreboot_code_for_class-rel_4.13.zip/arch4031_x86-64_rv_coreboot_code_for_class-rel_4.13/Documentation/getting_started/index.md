# Getting Started

* [coreboot architecture](architecture.md)
* [Build System](build_system.md)
* [Submodules](submodules.md)
* [Kconfig](kconfig.md)
* [Gerrit Guidelines](gerrit_guidelines.md)
* [Documentation License](license.md)
* [Writing Documentation](writing_documentation.md)
* [Setting up GPIOs](gpio.md)
